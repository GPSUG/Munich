Create database [PSSaturDay_Demo];
Use [PSSaturDay_Demo];
Create Table TestTable1 (
		TimeStamp datetime2 Default Current_TimeStamp, 
		ID int
);
