# Manager
bot help *webserver*

bot webstatus

bot escalateissue server

bot escalateissue webserver

# Jaap
bot webstatus
bot webstatus -detail

bot startweb -ComputerName webserver

bot webstatus -detail